package com.example.crud;

import jakarta.inject.Singleton;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.result.InsertOneResult;

import static com.mongodb.client.model.Filters.eq;

import java.util.Arrays;

/**
 *
 */
@Path("/hello")
@Singleton
public class HelloController {

    @GET
    public Response  sayHello() {
        String uri = "mongodb://localhost:27017";
        MongoCursor<Document> cursor2;
        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("EDOMEX");
            MongoCollection<Document> collection = database.getCollection("EMPLEADO");
            // Document doc = collection.find(eq("clave", 1)).first();
            Document doc = collection.find(eq("edad", 85)).first();
            //Document doc = collection.find(eq("nombre", "Peter")).first();

            if (doc != null) {
                System.out.println(doc.toJson());
            } else {
                System.out.println("No matching documents found.");
            }

            Bson projectionFields = Projections.fields(
                    Projections.include("clave", "nombre","paterno","materno","edad"),
                    Projections.excludeId());

                    MongoCursor<Document> cursor = collection.find(eq("edad", 85))
                    .projection(projectionFields)
                    .sort(Sorts.descending("title")).iterator();
                    cursor2=cursor;
                    try {
                        while(cursor.hasNext()) {
                            System.out.println(cursor.next().toJson());
                        }
                    } finally {
                        //cursor.close();
                    }


/* 
            try {
                for (int i = 2; i <= 1000000; i++) {
                    InsertOneResult result = collection.insertOne(new Document()
                            .append("_id", new ObjectId())
                            .append("clave",i)
                            .append("nombre", "Peter"+i)
                            .append("paterno", "Norton"+i)
                            .append("materno", "Gudh"+i)
                            .append("edad", getRandomNumber(1,100))
                            );
                    System.out.println("Success! Inserted document id: " + result.getInsertedId());
                }

            } catch (MongoException me) {
                System.err.println("Unable to insert due to an error: " + me);
            }
            */

            
        }
       
        return Response.status(Response.Status.OK).entity(cursor2.toString()).build();
    }
    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }
}
